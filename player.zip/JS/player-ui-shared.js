// player-ui-shared.js — PC/SP共通のUI操作。player-core.jsの後に読み込む。isMobileLayout()でPC/SP分岐する関数あり(renderPins等)。SECTIONコメントは将来分割時の切り出し目安


// welcomeOverlayは撤去済み(+ADD AUDIOへ一本化)。hideWelcomeOverlay()はloadFile等から呼ばれるので残す。要素が無ければ何もしない
function hideWelcomeOverlay() {
  const overlay = document.getElementById("welcomeOverlay");
  if (overlay) overlay.classList.add("hidden");
}



async function decodeForWaveform(arrayBuffer) {
  const OfflineCtx = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  if (OfflineCtx) {
    for (const rate of [8000, 22050]) {
      try {
        const offline = new OfflineCtx(1, 1, rate);
        return await offline.decodeAudioData(arrayBuffer.slice(0));
      } catch (err) {
      }
    }
  }
  const ctx = getAudioCtx();
  return await ctx.decodeAudioData(arrayBuffer.slice(0));
}

async function decodeWaveform(file, token) {
  try {
    const arrayBuffer = await file.arrayBuffer();
    if (token !== waveformDecodeToken) return;
    // 【v2.13.4 負荷対策】共有AudioContext(getAudioCtx)でデコードしない(通常再生でWeb Audioが常駐しiOS Safariで問題)。波形は4000ピークしか使わないので低サンプルレートのOfflineAudioContextでデコードしメモリを約1/5に
    const audioBuffer = await decodeForWaveform(arrayBuffer);

    if (token !== waveformDecodeToken) return;

    const channelCount = audioBuffer.numberOfChannels;
    const rawLength = audioBuffer.length;
    const samples = 4000;
    const blockSize = Math.max(1, Math.floor(rawLength / samples));
    const peaks = new Float32Array(samples);

    const channelData = [];
    for (let c = 0; c < channelCount; c++) {
      channelData.push(audioBuffer.getChannelData(c));
    }

    for (let i = 0; i < samples; i++) {
      const start = i * blockSize;
      const end = Math.min(rawLength, start + blockSize);
      let max = 0;
      for (let j = start; j < end; j++) {
        for (let c = 0; c < channelCount; c++) {
          const v = Math.abs(channelData[c][j]);
          if (v > max) max = v;
        }
      }
      peaks[i] = max;
    }

    let peakMax = 0;
    for (let i = 0; i < samples; i++) {
      if (peaks[i] > peakMax) peakMax = peaks[i];
    }
    if (peakMax > 0) {
      for (let i = 0; i < samples; i++) {
        peaks[i] = peaks[i] / peakMax;
      }
    }

    if (token !== waveformDecodeToken) return;

    waveformPeaks = peaks;
    drawWaveform();
  } catch (err) {
    console.warn("Waveform decode failed:", err);
    waveformPeaks = null;
  }
}

function drawWaveform() {
  if (!waveformPeaks || !audio.duration) return;
  window.__qnWaveformDrawCount = (window.__qnWaveformDrawCount || 0) + 1;
  const dur = audio.duration;
  const { s1, s2, s3, s4, s5 } = getSegments(dur);
  const bounds = [0, s1, s2, s3, s4, s5, dur];

  for (let row = 0; row < 6; row++) {
    const canvas = document.getElementById(`wave${row + 1}`);
    const bar = document.getElementById(`bar${row + 1}`);
    if (!canvas || !bar) continue;

    const rect = bar.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, Math.floor(rect.width * dpr));
    const h = Math.max(1, Math.floor(rect.height * dpr));
    if (canvas.width !== w) canvas.width = w;
    if (canvas.height !== h) canvas.height = h;

    const ctx2d = canvas.getContext("2d");
    ctx2d.clearRect(0, 0, canvas.width, canvas.height);

    const rowStart = bounds[row];
    const rowEnd = bounds[row + 1];
    const totalSamples = waveformPeaks.length;

    const startIdx = Math.floor((rowStart / dur) * totalSamples);
    const endIdx = Math.max(startIdx + 1, Math.floor((rowEnd / dur) * totalSamples));
    const sliceCount = endIdx - startIdx;
    if (sliceCount <= 0) continue;

    const barGap = 1 * dpr;
    const barWidth = Math.max(1, canvas.width / sliceCount - barGap);

    ctx2d.fillStyle = "rgba(255, 255, 255, 0.16)";

    for (let i = 0; i < sliceCount; i++) {
      const peak = waveformPeaks[startIdx + i] || 0;
      const barHeight = Math.max(2 * dpr, peak * canvas.height * 0.85);
      const x = i * (canvas.width / sliceCount);
      ctx2d.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
    }
  }
}

window.addEventListener("resize", () => {
  if (waveformPeaks) drawWaveform();
});

const savedVolume = localStorage.getItem("mp3player_volume");
if (savedVolume !== null) {
  audio.volume = parseFloat(savedVolume);
} else {
  audio.volume = 0.8;
}

const volumeDisplay = document.getElementById("volumeDisplay");
const controlVolumeDisplay = document.getElementById("controlVolumeDisplay");
if (volumeDisplay) volumeDisplay.textContent = audio.volume.toFixed(2);
if (controlVolumeDisplay) controlVolumeDisplay.textContent = audio.volume.toFixed(2);

function updateAvToggleValue(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

updateAvToggleValue("volToggleValue", Math.round(audio.volume * 100) + "%");

function applyVolumeChange(val) {
  audio.volume = val;
  if (volumeDisplay) volumeDisplay.textContent = val.toFixed(2);
  if (controlVolumeDisplay) controlVolumeDisplay.textContent = val.toFixed(2);
  updateAvToggleValue("volToggleValue", Math.round(val * 100) + "%");
  localStorage.setItem("mp3player_volume", val);
}

[document.getElementById("volume"), document.getElementById("controlVolume")].forEach(input => {
  if (!input) return;
  input.value = audio.volume;
  input.oninput = e => {
    const otherInput = input.id === "volume" ? document.getElementById("controlVolume") : document.getElementById("volume");
    const val = parseFloat(e.target.value);
    if (otherInput) otherInput.value = val;
    applyVolumeChange(val);
  };
});

document.getElementById("fileInput").onchange = e => addFilesToPlaylist(Array.from(e.target.files));



// 直前のobjectURL。曲切替時にrevokeObjectURL()で必ず解放(忘れると曲数×サイズ分メモリが積み上がりモバイルでクラッシュ)
let currentObjectUrl = null;

function loadFile(file) {
  if (!file) return;
  
  setAppTitle(file.name);
  hideWelcomeOverlay();

  loopActiveMarkerIndex = null;

  if (currentObjectUrl) {
    URL.revokeObjectURL(currentObjectUrl);
    currentObjectUrl = null;
  }

  const url = URL.createObjectURL(file);
  currentObjectUrl = url;
  audio.src = url;
  audio.load();
  updatePlaybackRate();

  // setupAudioGraph()は曲読込時に呼ばない(常時Web Audio接続だとiOS Safariで長時間再生後にクラッシュ。Safari固有)。EQボタン等の実操作時のみ(setupAudioGraphOnDemand)

  waveformPeaks = null;
  waveformDecodeToken++;
  decodeWaveform(file, waveformDecodeToken);

  // 【v2.13.6】マーカー/テキストメモ読込は曲切替の瞬間に同期で行う(loadedmetadata待ちだと失敗時に曲名だけ新しく本文が前の曲のままになり、編集すると新しい曲名キーで保存される。GOTCHAS.md)
  const savedPins = localStorage.getItem("mp3_pins_" + file.name);
  if (savedPins) {
    try {
      const raw = JSON.parse(savedPins);
      pins = raw.map(p => typeof p === 'number' ? { t: p, enabled: true, memo: "", color: null } : { t: p.t, enabled: p.enabled !== false, memo: p.memo || "", color: p.color || null });
    } catch (e) { pins = []; }
  } else {
    pins = [];
  }
  loadABFor(file.name);
  if (typeof renderPinList === "function") renderPinList();

  // noteTextAreaEl(player-text.js)に依存せず都度DOM取得(読み込み順非依存)。フルスクリーン表示中ならそちらも更新
  const noteTextForLoad = localStorage.getItem("mp3_text_" + file.name) || "";
  const noteTextAreaElForLoad = document.getElementById("noteTextArea");
  if (noteTextAreaElForLoad) noteTextAreaElForLoad.value = noteTextForLoad;
  const noteTextAreaFsForLoad = document.getElementById("noteTextAreaFullscreen");
  if (noteTextAreaFsForLoad) noteTextAreaFsForLoad.value = noteTextForLoad;

  audio.onloadedmetadata = () => {
    prevTime = audio.currentTime;
    drawWaveform();

    renderPins();
    renderSegments();
    renderPinList();
    if (window.__qnAudioCtx && window.__qnAudioCtx.state === "suspended") {
      window.__qnAudioCtx.resume().catch(() => {});
    }
    // 読込後は自動再生しない(Play待ち)
    updatePlayButtonState();
  };
}



function updatePlayButtonState() {
  const playBtn = document.getElementById("playToggle");
  updateMediaSessionPlaybackState();
  if (!playBtn) return;

  const label = playBtn.querySelector(".top-controls-btn-label");
  const labelText = label ? label.textContent : "";

  if (!audio.paused) {
    playBtn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>';
    playBtn.style.background = "linear-gradient(135deg, #10b981, #059669)";
    playBtn.style.boxShadow = "0 6px 20px rgba(16, 185, 129, 0.4)";
  } else {
    playBtn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>';
    playBtn.style.background = "";
    playBtn.style.boxShadow = "";
  }

  const newLabel = document.createElement("span");
  newLabel.className = "top-controls-btn-label";
  newLabel.textContent = labelText || "Play";
  playBtn.appendChild(newLabel);
}

function togglePlay() {
  hapticTap();
  // ユーザー操作の直接起点でAudioContextをresume
  if (window.__qnAudioCtx && window.__qnAudioCtx.state === "suspended") {
    window.__qnAudioCtx.resume().catch(() => {});
  }

  if (audio.paused) {
    audio.play();
  } else {
    audio.pause();
  }
  updatePlayButtonState();
}

function updateMediaSessionMetadata(name) {
  if (!("mediaSession" in navigator)) return;
  try {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: name || "QNPLAYER",
      artist: "QNPLAYER"
    });
  } catch (e) {
  }
}

function updateMediaSessionPlaybackState() {
  if (!("mediaSession" in navigator)) return;
  navigator.mediaSession.playbackState = audio.paused ? "paused" : "playing";
}

if ("mediaSession" in navigator) {
  navigator.mediaSession.setActionHandler("play", () => togglePlay());
  navigator.mediaSession.setActionHandler("pause", () => togglePlay());
  navigator.mediaSession.setActionHandler("previoustrack", () => {
    const prevIndex = findEnabledTrackIndex(currentPlaylistIndex, -1, false);
    if (prevIndex !== -1) playTrackAt(prevIndex);
  });
  navigator.mediaSession.setActionHandler("nexttrack", () => {
    const nextIndex = findEnabledTrackIndex(currentPlaylistIndex, 1, false);
    if (nextIndex !== -1) playTrackAt(nextIndex);
  });
}

let audioContextWatchTimer = null;
function startAudioContextWatch() {
  if (audioContextWatchTimer) return;
  audioContextWatchTimer = setInterval(() => {
    if (window.__qnAudioCtx && window.__qnAudioCtx.state === "suspended") {
      console.warn("AudioContext became suspended during playback — attempting to resume.");
      window.__qnAudioCtx.resume().catch(err => console.warn("AudioContext resume failed:", err));
    }
  }, 2000);
}
function stopAudioContextWatch() {
  if (audioContextWatchTimer) {
    clearInterval(audioContextWatchTimer);
    audioContextWatchTimer = null;
  }
}

audio.onplay = () => {
  updatePlayButtonState();
  startAudioContextWatch();
};
audio.onpause = () => {
  updatePlayButtonState();
  stopAudioContextWatch();
};
audio.onended = () => {
  // iOSはBluetooth瞬断等で曲の途中に"ended"が誤発火する。currentTimeがdurationの1秒以内か確認し、途中なら次曲へ進まず同位置から再開
  const dur = audio.duration;
  const ct = audio.currentTime;
  const reallyEnded = !dur || !isFinite(dur) || (dur - ct) < 1;

  if (!reallyEnded) {
    console.warn(`Spurious 'ended' event detected at ${ct.toFixed(1)}s / ${dur.toFixed(1)}s — resuming playback instead of advancing.`);
    audio.play().catch(err => console.warn("Resume after spurious ended failed:", err));
    updatePlayButtonState();
    return;
  }

  updatePlayButtonState();

  if (repeatMode === "one") {
    audio.currentTime = 0;
    audio.play();
    updatePlayButtonState();
    return;
  }

  const wrapAround = repeatMode === "all";
  const nextIndex = findEnabledTrackIndex(currentPlaylistIndex, 1, wrapAround);
  if (nextIndex !== -1) {
    playTrackAt(nextIndex);
  } else {
    // 次のON曲が無く停止する場合は再生中監視も明示的に止める(onpauseが発火しないため)
    stopAudioContextWatch();
  }
};

// 【v2.13.5 保険】読込失敗時はIndexedDBから読み直して1回だけ再試行(GOTCHAS.md)
let lastAudioRecoveryName = null;
audio.addEventListener("error", async () => {
  if (typeof currentPlaylistIndex === "undefined" || currentPlaylistIndex < 0) return;
  const track = playlist[currentPlaylistIndex];
  if (!track || !track.file) return;
  const name = track.file.name;
  if (lastAudioRecoveryName === name) return; // 同じ曲で無限再試行しない
  lastAudioRecoveryName = name;
  console.warn("Audio load failed — reloading track data from storage:", name);
  const fresh = typeof reloadTrackFileFromDB === "function" ? await reloadTrackFileFromDB(name) : null;
  if (!fresh || playlist[currentPlaylistIndex] !== track) return;
  track.file = fresh;
  loadFile(fresh);
  audio.play().catch(() => {});
});
audio.addEventListener("loadedmetadata", () => { lastAudioRecoveryName = null; });

document.getElementById("playToggle").onclick = togglePlay;



const prevTrackBtn = document.getElementById("prevTrackBtn");
if (prevTrackBtn) prevTrackBtn.onclick = () => playPrevTrack();

const nextTrackBtn = document.getElementById("nextTrackBtn");
if (nextTrackBtn) nextTrackBtn.onclick = () => playNextTrack();

document.addEventListener("keydown", e => {
  if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
  // アプリ(YouTube等)表示中は本体ショートカットを無効(qn-apps.js参照)
  if (document.body.classList.contains("qn-app-open")) return;

  const activePins = pins.filter(p => p.enabled);

  if (e.code === "Space" || e.key === " ") {
    e.preventDefault();
    togglePlay();
  }
  else if (e.key === "Enter") {
    e.preventDefault();
    if (typeof seekToTrackStart === "function") seekToTrackStart();
  }
  else if (e.key === "l" || e.key === "L") {
    e.preventDefault();
    const loopBtn = document.getElementById("loopToggleBtn");
    if (loopBtn) loopBtn.click();
  }
  else if (e.ctrlKey && (e.key === "r" || e.key === "R")) {
    e.preventDefault();
    const speedResetBtnEl = document.getElementById("controlSpeedResetBtn");
    if (speedResetBtnEl && !speedResetBtnEl.disabled) speedResetBtnEl.click();
    const keyResetBtnEl = document.getElementById("controlKeyResetBtn");
    if (keyResetBtnEl && !keyResetBtnEl.disabled) keyResetBtnEl.click();
  }
  else if (e.key === "r" || e.key === "R") {
    e.preventDefault();
    const allRepeatBtn = document.getElementById("allRepeatToggleBtn");
    if (allRepeatBtn) allRepeatBtn.click();
  }
  else if (e.key === "p" || e.key === "P" || e.key === "m" || e.key === "M") {
    e.preventDefault();
    addCurrentPin();
  }
  else if (e.ctrlKey && e.key === "ArrowRight") {
    e.preventDefault();
    setSpeed(currentSpeed + 0.01);
  }
  else if (e.ctrlKey && e.key === "ArrowLeft") {
    e.preventDefault();
    setSpeed(currentSpeed - 0.01);
  }
  else if (e.ctrlKey && e.key === "ArrowUp") {
    e.preventDefault();
    const keyUpBtnEl = document.getElementById("keyUpBtn");
    if (!keyUpBtnEl || !keyUpBtnEl.disabled) setKeySemitones(currentKeySemitones + 1);
  }
  else if (e.ctrlKey && e.key === "ArrowDown") {
    e.preventDefault();
    const keyDownBtnEl = document.getElementById("keyDownBtn");
    if (!keyDownBtnEl || !keyDownBtnEl.disabled) setKeySemitones(currentKeySemitones - 1);
  }
  else if (e.key === "ArrowRight") {
    e.preventDefault();
    jumpToNextMarker();
  }
  else if (e.key === "ArrowLeft") {
    e.preventDefault();
    jumpToPrevMarker();
  }
  else if (e.key === "ArrowUp") {
    if (activePins.length > 0) {
      e.preventDefault();
      beginSeek();
      audio.currentTime = activePins[0].t;
      prevTime = activePins[0].t;
      audio.play();
      updatePlayButtonState();
      renderSegments(getActiveSegment(activePins[0].t));
      setTimeout(() => { isSeeking = false; }, 150);
    }
  }
  else if (e.key === "ArrowDown") {
    if (activePins.length > 0) {
      e.preventDefault();
      beginSeek();
      audio.currentTime = activePins[activePins.length - 1].t;
      prevTime = activePins[activePins.length - 1].t;
      audio.play();
      updatePlayButtonState();
      renderSegments(getActiveSegment(activePins[activePins.length - 1].t));
      setTimeout(() => { isSeeking = false; }, 150);
    }
  }
  else if (e.ctrlKey && e.key >= "1" && e.key <= "9") {
    e.preventDefault();
    const index = parseInt(e.key) - 1;
    if (pins[index] !== undefined) {
      pins[index].enabled = !pins[index].enabled;
      renderPins();
      renderSegments();
      renderPinList();
      savePins();
    }
  }
  else if (!e.ctrlKey && e.key >= "1" && e.key <= "9") {
    const index = parseInt(e.key) - 1;
    if (pins[index] !== undefined) {
      e.preventDefault();
      beginSeek();
      audio.currentTime = pins[index].t;
      prevTime = pins[index].t;
      audio.play();
      updatePlayButtonState();
      renderSegments(getActiveSegment(pins[index].t));
      setTimeout(() => { isSeeking = false; }, 150);
    }
  }
});







// updateBarsは毎フレーム呼ばれる: 配列/DOM参照は使い回す(GC抑制)。時刻・.vbar-fillの見た目はUPDATE_BARS_VISUAL_INTERVAL_MSで間引く。マーカー区間ループの折り返し判定は精度のため間引かず毎フレーム
const updateBarsFillEls = [1, 2, 3, 4, 5, 6].map(i => document.getElementById(`fill${i}`));
const updateBarsCurrentValEl = document.getElementById("currentTimeVal");
const updateBarsDurationValEl = document.getElementById("durationVal");
const updateBarsP = [0, 0, 0, 0, 0, 0];
const updateBarsThresholds = [0, 0, 0, 0, 0, 0, 0];
const UPDATE_BARS_VISUAL_INTERVAL_MS = 100;
let lastVisualUpdateTime = 0;
let lastCurrentTimeText = null;
let lastDurationText = null;
const updateBarsLastP = [-1, -1, -1, -1, -1, -1];

function updateBars() {
  requestAnimationFrame(updateBars);
  if (!audio.duration) return;

  const dur = audio.duration;
  const ct = audio.currentTime;
  const now = performance.now();

  if (now - lastVisualUpdateTime >= UPDATE_BARS_VISUAL_INTERVAL_MS) {
    lastVisualUpdateTime = now;

    if (updateBarsCurrentValEl && updateBarsDurationValEl) {
      const ctText = formatTime(ct);
      const durText = formatTime(dur);
      if (ctText !== lastCurrentTimeText) {
        updateBarsCurrentValEl.textContent = ctText;
        lastCurrentTimeText = ctText;
      }
      if (durText !== lastDurationText) {
        updateBarsDurationValEl.textContent = durText;
        lastDurationText = durText;
      }
    }

    const step = dur / 6;
    updateBarsThresholds[0] = 0;
    updateBarsThresholds[1] = step;
    updateBarsThresholds[2] = step * 2;
    updateBarsThresholds[3] = step * 3;
    updateBarsThresholds[4] = step * 4;
    updateBarsThresholds[5] = step * 5;
    updateBarsThresholds[6] = dur;

    for (let i = 0; i < 6; i++) {
      if (ct >= updateBarsThresholds[i + 1]) {
        updateBarsP[i] = 100;
      } else if (ct > updateBarsThresholds[i]) {
        updateBarsP[i] = ((ct - updateBarsThresholds[i]) / (updateBarsThresholds[i + 1] - updateBarsThresholds[i])) * 100;
        break;
      } else {
        updateBarsP[i] = 0;
      }
    }

    for (let i = 0; i < 6; i++) {
      if (updateBarsFillEls[i] && updateBarsP[i] !== updateBarsLastP[i]) {
        updateBarsFillEls[i].style.width = updateBarsP[i] + "%";
        updateBarsLastP[i] = updateBarsP[i];
      }
    }
  }

  // 折り返し判定は毎フレーム(間引かない)。loopEnabled判定を先に(OFFなら配列生成しない)。v3.7.0〜: A-Bループはloop WrapAB()
  if (loopEnabled && loopMode === "ab" && !isSeeking && !isJumping && !audio.paused) {
    const abr = getABRange();
    if (abr) loopWrapAB(abr, ct);
  }

  if (loopEnabled && loopMode !== "ab" && !isSeeking && !isJumping && !audio.paused) {
    const activePinObjs = pins.filter(p => p.enabled);
    const activePins = activePinObjs.map(p => p.t);
    if (activePins.length >= 2) {
      const preroll = typeof loopPreRollSeconds === "number" ? loopPreRollSeconds : 0;

      // 対象区間未決定、またはctがpre/post-roll込みの許容範囲外なら現在地から再計算(個別イベントを検知せずとも区間外なら自動追従)。判定ルールはYouTubeと共通(qn-marker-core.js)
      const inCurrentRange = QNMarkerCore.inSectionRange(activePins, loopActiveMarkerIndex, ct, preroll, audio.duration);

      if (!inCurrentRange) {
        const foundIndex = QNMarkerCore.pickSectionIndex(activePins, ct);
        loopActiveMarkerIndex = foundIndex;
      }

      const i = loopActiveMarkerIndex;
      const start = activePins[i];
      const end = activePins[i + 1];
      const jumpTarget = Math.max(0, start - preroll);
      const endPlayback = Math.min(audio.duration || end, end + preroll);

      if (prevTime < endPlayback && ct >= endPlayback) {
        let stoppedByShareware = false;
        if (typeof isUnlocked === "function" && !isUnlocked()) {
          swAbLoopCount++;
          swUpdateLoopCounterUI();
          if (swAbLoopCount >= SW_LIMITS.AB_LOOP_MAX_COUNT) {
            loopEnabled = false;
            swAbLoopCount = 0;
            if (typeof applyLoopButtonUI === "function") applyLoopButtonUI();
            swUpdateLoopCounterUI();
            swShowUnlockToast(`無料版のAB間ループは${SW_LIMITS.AB_LOOP_MAX_COUNT}回で自動停止します。`);
            stoppedByShareware = true;
          }
        }
        if (!stoppedByShareware) {
          audio.currentTime = jumpTarget;
          isJumping = true;
          // 開始側マーカーのcolorを引き継ぐ({start,end}だけだとcolor undefinedでrenderSegmentsがデフォルト色になり2周目以降で色が消える)
          renderSegments({ start, end, color: activePinObjs[i].color || null });
          notifyLoopCompleted();
          setTimeout(() => {
            isJumping = false;
          }, 200);
        }
      }
    }
  }

  prevTime = audio.currentTime;
}

updateBars();

function loopWrapAB(abr, ct) {
  const preroll = typeof loopPreRollSeconds === "number" ? loopPreRollSeconds : 0;
  const jumpTarget = Math.max(0, abr.start - preroll);
  const endPlayback = Math.min(audio.duration || abr.end, abr.end + preroll);
  if (!(prevTime < endPlayback && ct >= endPlayback)) return;

  if (typeof isUnlocked === "function" && !isUnlocked()) {
    swAbLoopCount++;
    swUpdateLoopCounterUI();
    if (swAbLoopCount >= SW_LIMITS.AB_LOOP_MAX_COUNT) {
      loopEnabled = false;
      swAbLoopCount = 0;
      if (typeof applyLoopButtonUI === "function") applyLoopButtonUI();
      swUpdateLoopCounterUI();
      swShowUnlockToast(`無料版のAB間ループは${SW_LIMITS.AB_LOOP_MAX_COUNT}回で自動停止します。`);
      return;
    }
  }
  audio.currentTime = jumpTarget;
  isJumping = true;
  renderSegments({ start: abr.start, end: abr.end, color: abr.color });
  notifyLoopCompleted();
  setTimeout(() => { isJumping = false; }, 200);
}

function abLeaveIfOutside(t) {
  if (!loopEnabled || loopMode !== "ab") return;
  const abr = typeof getABRange === "function" ? getABRange() : null;
  if (!abr) return;
  if (!QNMarkerCore.isOutsideAB(abr.start, abr.end, t)) return;
  if (typeof setLoopModeState === "function") setLoopModeState("off", true);
  else { loopEnabled = false; if (typeof applyLoopButtonUI === "function") applyLoopButtonUI(); }
}

function calcTimeFromBarPosition(bar, barIndex, clientX) {
  const rect = bar.getBoundingClientRect();
  const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
  const dur = audio.duration;
  const { s1, s2, s3, s4, s5 } = getSegments(dur);
  const boundaries = [0, s1, s2, s3, s4, s5, dur];
  return boundaries[barIndex] + ratio * (boundaries[barIndex + 1] - boundaries[barIndex]);
}

document.querySelectorAll(".vbar").forEach((bar, index) => {
  bar.addEventListener("click", e => {
    if (typeof lastPinTapAt !== "undefined" && Date.now() - lastPinTapAt < 400) return;
    beginSeek();

    const clickedTime = calcTimeFromBarPosition(bar, index, e.clientX);
    abLeaveIfOutside(clickedTime);

    audio.currentTime = clickedTime;
    prevTime = clickedTime;

    renderSegments(getActiveSegment(clickedTime));
    audio.play();
    updatePlayButtonState();

    setTimeout(() => {
      isSeeking = false;
    }, 150);

    if (typeof showPinPopup === "function") showPinPopup(clickedTime, bar, e.clientX, null);
  });
});




const isMobileLayout = () => window.matchMedia("(max-width: 768px)").matches;



const mobileTabBtns = document.querySelectorAll(".mobile-tab-btn");
let currentMobileTab = "playlist";

function applyMobileTabLayout() {
  document.querySelectorAll(".mobile-tab-panel").forEach(panel => {
    const tabName = panel.getAttribute("data-tab-panel");
    panel.classList.toggle("mobile-tab-active", tabName === currentMobileTab);
  });
}

function setMobileTab(tabName) {
  currentMobileTab = tabName;
  mobileTabBtns.forEach(btn => {
    btn.classList.toggle("active", btn.getAttribute("data-tab") === tabName);
  });
  applyMobileTabLayout();
  if (typeof updateSidebarHeightForTextTab === "function") {
    updateSidebarHeightForTextTab();
  }
}


const sidebarSection = document.getElementById("sidebarSection");

// EQセクションは常にEQモーダル内に留める(SPでスクロールとEQスライダーのドラッグが競合するため)
const eqInlineSection = document.getElementById("eqInlineSection");
let eqInlineOrigin = null;
if (eqInlineSection) {
  eqInlineOrigin = {
    parent: eqInlineSection.parentNode,
    nextSibling: eqInlineSection.nextSibling
  };
}

function applyEqInlineLayout() {
  if (!eqInlineSection || !eqInlineOrigin) return;
  if (eqInlineSection.parentNode !== eqInlineOrigin.parent) {
    eqInlineOrigin.parent.insertBefore(eqInlineSection, eqInlineOrigin.nextSibling);
  }
}

mobileTabBtns.forEach(btn => {
  btn.onclick = () => {
    hapticTap();
    setMobileTab(btn.getAttribute("data-tab"));
  };
});

setMobileTab("playlist");
applyEqInlineLayout();

function syncAllMobileLayout() {
  applyEqInlineLayout();
}
window.addEventListener("resize", syncAllMobileLayout);

function syncTopControlsSpacerHeight() {
  const topControls = document.getElementById("topControls");
  const spacer = document.getElementById("topControlsSpacer");
  const sidebarSection = document.querySelector(".sidebar-section");
  const mobileTabPanels = document.querySelectorAll(".mobile-tab-panel");
  if (!topControls || !spacer) return;

  const h = topControls.getBoundingClientRect().height;

  // topControlsはfixed。body下端にその高さ分の余白を確保(無いと最下部の項目が裏に隠れる)
  spacer.style.height = h + "px";

  // 各要素が実際に.app-container内に留まっているかで判定する(body.pc-v2-activeでの判定は読み込み順で取りこぼす。PC v2は要素を#pcV2PanelBody内へ移すので、移動済み要素にpadding-bottomを付けると不要な余白になる)
  mobileTabPanels.forEach(panel => {
    const stillInAppContainer = !!panel.closest(".app-container");
    if (!stillInAppContainer) {
      panel.style.paddingBottom = "";
      return;
    }
    if (isMobileLayout()) {
      // SP幅はbodyがoverflow:hiddenでスクロールしない。実スクロールは.sidebar-section内の.mobile-tab-panelなので、そちらにtopControls高さ分の余白(.sidebar-sectionにpaddingしても無効)
      panel.style.paddingBottom = (h + 8) + "px";
    } else {
      panel.style.paddingBottom = "";
    }
  });

  if (isMobileLayout()) {
    if (sidebarSection) sidebarSection.style.paddingBottom = "";
    document.body.style.paddingBottom = "";
  } else {
    document.body.style.paddingBottom = "";
    if (sidebarSection) sidebarSection.style.paddingBottom = "";
  }
}
syncTopControlsSpacerHeight();
window.addEventListener("resize", syncTopControlsSpacerHeight);

window.onload = async () => {
  updatePlayButtonState();
  syncTopControlsSpacerHeight();

  const splashStart = Date.now();
  const splashMinDurationMs = 1400;

  try {
    await restorePlaylistFromStorage();
  } catch (e) {
    // 復元失敗でもスプラッシュは必ず消す(エラーはconsole)
    console.error("restorePlaylistFromStorage failed:", e);
  }

  const elapsed = Date.now() - splashStart;
  const remaining = Math.max(0, splashMinDurationMs - elapsed);
  setTimeout(hideSplashOverlay, remaining);
};

function hideSplashOverlay() {
  const splash = document.getElementById("splashOverlay");
  if (!splash) return;
  splash.classList.add("splash-fade-out");
  setTimeout(() => {
    splash.style.display = "none";
  }, 550);
}

// 起動時にIndexedDBの全曲を復元。自動再生しない(ユーザー操作なしplay()はブロックされ、意図せず鳴るのも避ける)。IndexedDBへ書き戻さない
async function restorePlaylistFromStorage() {
  const savedTracks = await loadAllPlaylistTracks();
  if (savedTracks.length === 0) return;

  savedTracks.forEach(({ file, enabled, title, artist, favorite, folder }) => {
    playlist.push({ file, name: file.name, enabled, title: title || null, artist: artist || null, duration: null, favorite: !!favorite, folder: folder || null });
  });
  if (typeof normalizePlaylistGrouping === "function") normalizePlaylistGrouping();
  renderPlaylist();

  playlist.forEach(track => {
    if (typeof readAudioDuration === "function") {
      readAudioDuration(track.file).then(dur => {
        if (dur) {
          track.duration = dur;
          renderPlaylist();
        }
      });
    }
  });

  // 1曲目を選曲済みにする(autoplay:false)
  playTrackAt(0, false);
}

// ハプティクス(非対応は無視): tap=押下/タブ切替/ポップアップ開閉/スウォッチ選択、tick=スライダー目盛り跨ぎ(呼び出し側で間引く)、success=マーカー追加/Export完了、warning=削除確認/エラー/上限下限到達
function hapticTap() {
  if (navigator.vibrate) navigator.vibrate(10);
}
function hapticTick() {
  if (navigator.vibrate) navigator.vibrate(6);
}
function hapticSuccess() {
  if (navigator.vibrate) navigator.vibrate([15, 40, 15]);
}
function hapticWarning() {
  if (navigator.vibrate) navigator.vibrate([20, 60, 20, 60, 20]);
}



(function syncRangeProgressLoop() {
  const targets = Array.from(document.querySelectorAll(".control-card input[type=\"range\"], .eq-vslider"));
  const lastValues = new Map();
  let lastTickAt = 0;
  function tick(now) {
    requestAnimationFrame(tick);
    if (document.hidden || (now - lastTickAt) < 200) return;
    lastTickAt = now;
    targets.forEach(input => {
      if (lastValues.get(input) !== input.value) {
        lastValues.set(input, input.value);
        const min = parseFloat(input.min) || 0;
        const max = parseFloat(input.max) || 100;
        const val = parseFloat(input.value);
        const pct = max > min ? ((val - min) / (max - min)) * 100 : 0;
        input.style.setProperty("--range-progress", String(pct));
      }
    });
  }
  if (targets.length > 0) requestAnimationFrame(tick);
})();
