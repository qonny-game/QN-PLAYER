# QN-PLAYER バージョン履歴

`window.QN_APP_VERSION`更新ごとに**末尾へ1行追記**（`- 版 一言`）。経緯・不具合の詳細は書かない（再発しうる教訓だけ`GOTCHAS.md`）。

- 〜3.20.0 PLAYER(PC v2)＋アプリ基盤(QNApps)＋YouTubeアプリ(Library/Markers/3行シークバー/A-B/Auto Next/Backup・Import共通画面)まで実装済み。詳細は各mdの現行仕様を参照。
- 3.20.1 未使用JS関数・未使用CSSクラスを削除（動的クラス`.is-a/.is-b`・`.pcv2-panel-*`は残す）。
- 3.20.2 未使用id削除、重複関数統合、大型ファイル分割(`style-youtube.css`/`style-layout-pc-v2-sp.css`/`player-marker-presets.js`)、md整理。`player-ui-pc-v2.js`/`qn-app-youtube.js`は共有変数が多く分割しない。
- 3.20.3 JS/CSS/HTMLのコメントを「注意・禁止・規約・順序依存・仕様メモ」だけに圧縮。検証用swDebugコード(JS/CSS)と無効なCSSルール(`.tripleNavBtn`重複)を削除。
- 3.20.4 YouTubeに無断アップロード禁止の注意書きを再表示、Set A/Bのツールチップ修正。Backup/Importの外枠(モーダル)とPC v2の旧レイアウト復元処理(`deactivate`/anchor)を削除し、Backup/Import表示を`qnBackupMount`に一本化。
- 3.21.0 TUNERアプリを追加(qn-app-tuner.js/qn-pitch-core.js/style-tuner.css)。Mic Tuner(Gauge/Guitar Meter)・Tone Generator・Sensitivity・Display。PLAYERのパネル/下段バー/部品デザインで統一。QNPITCH(旧アプリ)から移植、保存キーはqn_tuner_*で新規。
- 3.22.0 PITCHアプリを追加(qn-app-pitch.js/qn-pitch-filters.js/style-pitch.css)。ピッチロール(仮想スクロール)・録音(MediaRecorder+解析で1本のマイク共有)・再生・スコア・Filters・Recordings(EDIT/削除/改名)。QNPITCH(旧アプリ)から移植、保存キーはqn_pitch_*・DBはqn_pitch_dbで新規。Backup/Importは次段階。
- 3.23.0 PITCHのBackup/Importを追加。共通Backup/Import画面(player-track-backup.js)にPITCH録音の枠を追加(pitch.json+pitch/音声をZIPへ。PLAYER/YouTubeと同じZIPに同梱可・Import自動判定・重複は上書き/スキップ)。PITCHアプリのサイドバーにBackup/Import。
- 3.23.1 TUNER/PITCHのマイク使用中表示を追加(ステージ右上/左上の「MIC ON」「REC」ピル+入力レベル、サイドバーのアプリバッジに赤丸)。PITCHのStopアイコン修正。
- 3.23.2 テーマ色背景のボタン(サイドバーのホバー/アプリ名バッジ/フライアウト等)の文字・アイコン色を黒→白に変更(--sidebar-on-accent)。
- 3.24.0 ライブラリをフォルダ分け可能に(1階層・1曲=1フォルダ。データはネスト拡張可能な形)。見出しの開閉、NEW FOLDERで作成、EDITで改名/▲▼並び替え/✕削除(中の曲は未分類へ)、曲を選んでMOVEで移動。Auto Nextの範囲を「フォルダ内/全体」で切替(Libraryヘッダーの NEXT ボタン。前/次ボタン・メディアキーも同じ範囲)。Backup/Importにフォルダ名を含む(旧バックアップはそのまま読める)。無料版はフォルダ作成・移動を不可。
