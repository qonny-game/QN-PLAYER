# QN-PLAYER 落とし穴集（作る前・直す前に見る）

過去に実際に踏んだ不具合から、**これからも再発しうるものだけ**を残した。
静的チェック（`node --check`等）では見つからず、実機（特にiOS Safari）でしか症状が出ないものが多い。

## 1. 再生・音声・保存
- **IndexedDBの音声レコードは「書いたら二度と書き直さない」。** iOS(WebKit)ではBlobの中身が同じでも`put`し直すと実体が作り直され、メモリ上のFileが読めなくなる（並び替え後に再生不能になった原因）。並び順・ON/OFF・表示名・お気に入りなど頻繁に変わる情報は`localStorage`の`qn_playlist_meta_v1`へ。IndexedDBに書くのは「ユーザーが新しく与えた音声」だけ。全曲ループ処理を書く時は「Blobごと書き直していないか」を必ず疑う。
- **`audio.play()`はタップのコールスタック内で同期的に、重いDOM再構築より先に**呼ぶ（モバイルの自動再生ポリシー。`playTrackAt()`参照）。
- **削除は「メモリ上」と「永続化」の両方**を確認する。`playlist.splice()`の前に削除対象名を控え、`deletePlaylistTrack(name)`を呼ぶ。
- **曲名キーで保存するデータ（マーカー・テキスト）は、曲名を切り替えた同じ瞬間に同期で読み込む。** `loadedmetadata`待ちにすると、読み込み失敗時に前の曲の内容が残り、新しい曲名キーで保存されて複製される。
- **再生中の音声経路を差し替える処理（`createMediaElementSource`等）は、重い準備を全部先に終え、切り替えは`await`なしで一気に。** 間に非同期を挟むとその間だけ無音になる。
- デコードだけなら`OfflineAudioContext`（低サンプルレート）。`getAudioCtx()`は再生用のリアルタイムAudioContextを作るので、デコード目的で呼ばない。
- バックグラウンド再生はOS/ブラウザ次第（iOSはWeb Audio経由にすると止まりやすい）。ロック画面の一時停止と喧嘩するので、pauseを検知して自動`play()`し直す実装は避ける。実機でしか確認できない。
- 再生系コアが無変更なのに挙動が変わったら、追加ファイル（Wake Lock等）を1つずつ止めて切り分ける。

## 2. ループ・マーカー・シーク
- **シークを始める箇所は必ず`beginSeek()`を経由**（`isSeeking = true`を直接書かない）。`loopActiveMarkerIndex`（今ループ対象の区間）のリセット漏れで、シーク先が前の区間のループに引き戻される。
- プリロール/ポストロール中は、再生位置ではなく「今聴いている区間」を基準にする（前/次マーカー移動は`getMarkerNavReferenceTime()`。共通ルールは`JS/qn-marker-core.js`）。
- **ドラッグ中（特にタッチ）は、つかんでいる要素を削除・再生成しない。** 位置だけ更新し、再描画・保存は離した時に1回。タッチの後続イベントはdocumentではなくタッチ開始要素に付ける。ドラッグ直後の`click`でポップアップが出ないよう時刻ガード（`lastPinDragAt`/`lastPinTapAt`）を使う。
- 常にダブル処理を疑う：`pointerup`とそのあとの`click`で二重に動かない設計にする。

## 3. 負荷（PC v2はSPでも常に動く）
- `requestAnimationFrame`ループを新設しない／するなら間引き＋変化なしならスキップ＋ループ内で`getBoundingClientRect`・`getComputedStyle`・配列/文字列の新規生成をしない。（毎フレーム全再描画でiOSがプロセスを落とした実績あり。現在の波形は約10回/秒＋署名比較）
- `textContent`・`style.xxx`を定期的に書く処理は、値が変わった時だけ書く。
- **`infinite`のCSSアニメーションを常時表示の要素に付けない**（スタイル再計算が張り付く）。回数を限定し、動かすのは`transform`/`opacity`だけ。
- **`backdrop-filter`・`filter`・大きな`box-shadow`を持つ全画面要素は、非表示時に必ず`none`＋`visibility:hidden`**（`blur(0px)`でも合成コストが残る）。

## 4. CSS・レイアウト
- **iOS:** タップで動く要素（とその子孫）に、`:hover`で`display`/`visibility`を変えるCSSを書かない（1回目のタップが`click`にならない）。必要なら`@media (hover: hover) and (pointer: fine)`で囲む。
- **横スクロールする入れ物（SPの下段バー）の中の`position:absolute`ポップアップは切り取られる。** 最初から`document.body`直下＋`position:fixed`で作る。ドラッグはPointer Events（マウス/タッチ両対応）。
- **`overflow-y:auto`の要素の中で`flex:1`を何段にも重ねて「残り高さを埋める」構成にしない**（iOSで内容が重なる）。かさばる部分に上限つきの高さを与えて自前でスクロールさせる。内側スクロール領域を画面いっぱいにすると外側へのスクロール受け渡しが難しくなるので控えめに。SPの見た目はChromeだけでは保証されない。
- **`display:grid`＋固定`grid-template-columns`の親に、条件付きで子要素の個数を変えない**（列がズレる）。増減させたい物は既存の列に入る入れ物（wrapper）の中へ。
- **CSSの`order`は整数のみ有効**（小数は無視され`0`扱い）。間に挟む余地を持たせて10刻みで採番する。
- 一覧の行の中に一時的なUI（プリセット・入力補助）を足して行の高さを変えない。ポップアップ（body直下・fixed）にする。
- markers/playlist共通セレクタのCSSを変える時は、両パネルのタップ判定の違い（markers＝`.del-btn`、playlist＝`.playlist-del-zone`、`.pin-del-zone`）を壊していないか確認する。
- 汎用セレクタ（`.playlistItem button`等）より優先させたい時は、親クラスを前置して詳細度を上げる。**既存ルールを`grep`で探してから足す**（CSSの別の場所の既存ルールが原因のことが多い）。
- 共通の器`.export-modal-*`はExport/EQ/Backup/Import全部で流用。新しいモーダルはまずこれを使えないか確認する（名前は`export`だが用途はExportに限らない）。

## 5. PC v2の仕組み
- **EDITモード中の削除・選択は`player-ui-pc-v2.js`の`attachSelectionHandlers()`がキャプチャ段階で先に奪う。** `player-playlist.js`等の`delBtn.onclick`を直しても発火しない。
- **パネル切替で中身をdocumentから切り離さない。** `getElementById`で更新する要素は非表示でもdocument内に置く（`stashPanelContents()`が`#pcV2PanelStash`へ退避。パネルに新しい実体を足したら対象リストにも追加）。
- 下段バー/アイコンバー周辺に要素を足す時は`syncBottomBarPosition()`も見直す（SP⇔PCでDOM位置を移動する）。
- DOMを「借りて移す」実装（Color/Backup/Import）は、閉じる経路（他アイコン・Esc・再押下・`close()`・アプリ切替）を全部洗って必ず元に戻す。戻さないとPLAYER側が空になる。
- ポップアップを足したら閉じる経路（外側タップ・Esc・項目選択・スクロール・resize/回転・アプリ切替）を全部洗う。タッチに`hover`は頼れない。
- `hidden`属性は`display:none`で遷移が効かない。開閉状態は`hidden`ではなく変数で持ち、遅延`hidden`はタイマーを取り消せるようにする。

## 5.5 ライブラリのフォルダ（v3.24.0）
- **`playlist[]`は常に「フォルダ順にグループ化」した並びを保つ**（`normalizePlaylistGrouping()`。未分類は末尾）。だから行の`data-index`=配列indexのまま、選択/削除/ドラッグ/Auto Nextがindexベースで動く。配列を直接いじってフォルダを変えたら必ずnormalize→`persistPlaylistOrder()`。
- 行は`#playlistBox`の直下に見出し(`.playlistFolderHeader`)と交互に並ぶ。`container.children`のindexを行番号に使うな（`data-index`か`getRowItems()`を使う）。折りたたみ中は行を描画しない（編集モードは全展開）。
- フォルダ操作でindexがズレる前に`window.playlistClearSelection()`。indexが変わらない再描画は`playlistReapplySelection()`が選択表示を戻す。
- ドラッグ並び替えは同じフォルダ内だけ（そのグループの配列スロットへ書き戻す）。お気に入りの上段固定もフォルダ内。
- Auto Nextの範囲は`findEnabledTrackIndex()`の1箇所（前/次・メディアキー・曲終了が全部通る）。フォルダ定義は`qn_folders_v1`、曲の所属はメタの`folder`（localStorageのみ。IndexedDBの音声は書かない）。
- Backupのmarkers.jsonにはフォルダ**名**で入れる（idは端末ごと）。キーが無い旧バックアップはフォルダを触らない。

## 6. 制限（無料版）・アプリ
- **制限チェックは「みんなが通る一番奥の関数」に置く**（例：`playTrackAt()`）。入口ごとに書くと、新しい入口（前/次ボタン・メディアキー・自動送り）で素通りする。
- 無料版制限（`SW_LIMITS`）は「新しく増やす」操作にだけ掛かる。インポートは復元用途なので意図的に無制限。新機能ごとに適用するか明示的に決める。
- 本体のCSSは`#pcV2PanelBody …`で限定されているものが多い。本体のクラスをアプリ（`.qn-yt`等）で流用する時は、同等のルールをアプリ側に写す。本体のデザインを変えたらアプリ側も追随する。
- フォーカスを持つ入力欄は、行をDOMに追加する**前**に`startEdit()`する（追加後だと後続の描画がフォーカスを奪う）。
- SP幅でYouTubeのプレイヤーを隠さない（規約。`YOUTUBE_APP.md`）。

## 7. 作業の進め方で得た教訓
- **大きな文字列置換で無関係なコードを巻き込んで消した実績あり。** 大きく書き換えたら、直前の版と関数名・トップレベル変数を`diff`して意図しない削除がないか確認する（`node --check`では見つからない）。
- 症状はユーザーのスクリーンショットが最重要の手がかり。確認できていないことは正直に書く。
- 実ブラウザは使えない。確認はローカルHTTPサーバー＋Playwright（ヘッドレスChromium）まで。YouTubeのIFrame APIは実ネットワークに出られないと読み込めない（`iframe_api`をモックに差し替える）。`file://`では動かない。
- 動的に組み立てるクラス名・idがある（`"is-" + kind`、`"pcv2-panel-" + panelId`、`eqBand0〜9`等）。**未使用判定は単純な文字列検索だけで決めない。**
